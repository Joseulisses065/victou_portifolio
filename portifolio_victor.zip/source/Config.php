<?php
    //CAMINHO BASE
    define("ROOT","http://localhost/PHP/portifolio_victor/");
    define("SITE","Victor Hugo");


//RECEBE A URI E RETORNA A URL CORRETA
function url(string $uri = null): string{
    if($uri){
        return ROOT."/{$uri}";
    }
    return ROOT;
}